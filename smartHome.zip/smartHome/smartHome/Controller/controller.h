#ifndef CONTROLLER_H
#define CONTROLLER_H
#include <QObject>
#include "widget.h"
#include <QTimer>
#include <QDebug>
#include <QThread>
#include <QString>
#include "monitorthread.h"
#include "beep.h"
#include "adc.h"
#include "sg90.h"
#include "sr04.h"
#include "motor.h"
#include "tcpclient.h"
#include "led.h"

class Controller : public QObject
{
    Q_OBJECT
public:
    Controller(Widget* view);
    ~Controller();
private:
    void setUpConnect();
    void startToHost();

private slots:
    void handleBtnClick(Widget::ButtonId id);
    void handleInfReceive(int value);
    void handleDataReceive(QString data);
    void handleTimer();

private:
    Widget* m_view;
    QTimer* m_timer;
    MonitorThread* m_infThread;
    Led* m_led;
    Sr04* m_sr04;
    Beep* m_beep;
    Sg90* m_sg90;
    Motor* m_motor;
    Adc* m_adc;
    TcpClient* m_client;
    int m_timeCount = 0;
};

#endif // CONTROLLER_H
