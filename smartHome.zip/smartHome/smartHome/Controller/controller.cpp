#include "controller.h"

Controller::~Controller()
{
    delete m_led;
    delete m_beep;
    delete m_sg90;
    delete m_adc;
    delete m_sr04;
    delete m_motor;
    delete m_infThread;
}

Controller::Controller(Widget* view)
{
    m_view = view;

    m_led = new Led();
    m_beep = new Beep();
    m_sg90 = new Sg90();
    m_adc = new Adc();
    m_sr04 = new Sr04();
    m_motor = new Motor();

     m_timer = new QTimer(this);
    m_client = new TcpClient(this);
    m_infThread = new MonitorThread(this);

    m_timer->start(100);
    m_infThread->start();

    startToHost();
    setUpConnect();
}

void Controller::handleBtnClick(Widget::ButtonId id)
{
    switch (id)
    {
        case Widget::BTN_LED:
            m_led->toggle();
            m_led->getStatus() ? m_view->upDataLed(Widget::DEVICE_LED,Widget::COLOR_GREEN): m_view->upDataLed(Widget::DEVICE_LED,Widget::COLOR_GREY);
            break;

        case Widget::BTN_BEEP:
            m_beep->toggle();
            m_beep->getStatus() ? m_view->upDataLed(Widget::DEVICE_BEEP,Widget::COLOR_GREEN): m_view->upDataLed(Widget::DEVICE_BEEP,Widget::COLOR_GREY);
            break;

        case Widget::BTN_SLIDER:
            m_sg90->setAngle(m_view->getSliderValue() * 10);
            m_view->setAngleLab(m_view->getSliderValue() * 10);
            break;

        case Widget::BTN_MOTOR_ENABLE:
            if(m_motor->getStatus() == Motor::DISABLE)
            {
                m_motor->setStatus(Motor::ENABLE);
                m_view->upDataLed(Widget::DEVICE_MOTOR_STATUS,Widget::COLOR_GREEN);
                m_view->setMotorBtn(Widget::BTN_MOTOR_ENABLE,"Stop");
            }
            else
            {
                m_motor->setStatus(Motor::DISABLE);
                m_view->upDataLed(Widget::DEVICE_MOTOR_STATUS,Widget::COLOR_GREY);
                m_view->setMotorBtn(Widget::BTN_MOTOR_ENABLE,"Enable");
            }
            break;

        case Widget::BTN_MOTOR_DIR:
            if(m_motor->getDirection() == Motor::LEFT)
            {
                m_motor->setDirection(Motor::RIGHT);
                m_view->upDataLed(Widget::DEVICE_MOTOR_DIR,Widget::COLOR_RED);
                m_view->setMotorBtn(Widget::BTN_MOTOR_DIR,"Right");
            }
            else
            {
                m_motor->setDirection(Motor::LEFT);
                m_view->upDataLed(Widget::DEVICE_MOTOR_DIR,Widget::COLOR_YELLOW);
                m_view->setMotorBtn(Widget::BTN_MOTOR_DIR,"Left");
            }
            break;

        case Widget::BTN_MOTOR_SPEED:
            if(m_motor->getSpeed() == Motor::SPEED_LOW)
            {
                m_motor->setSpeed(Motor::SPEED_MIDDLE);
                m_view->setMotorPro(2);
                m_view->setMotorBtn(Widget::BTN_MOTOR_SPEED,"Middle");
            }
            else if(m_motor->getSpeed() == Motor::SPEED_MIDDLE)
            {
                m_motor->setSpeed(Motor::SPEED_HIGH);
                m_view->setMotorPro(3);
                m_view->setMotorBtn(Widget::BTN_MOTOR_SPEED,"Hight");
            }
            else
            {
                m_motor->setSpeed(Motor::SPEED_LOW);
                m_view->setMotorPro(1);
                m_view->setMotorBtn(Widget::BTN_MOTOR_SPEED,"Low");
            }
            break;

        default:
            qDebug() << "vaild id";
            break;
    }
}

void Controller::handleTimer()
{
    m_view->setLightPro(m_adc->getValue1());
    m_view->setLightLab(m_adc->getValue1() * m_adc->getScale1() / 1000.0);

    m_view->upDateChart(m_timeCount, m_sr04->getDistanceCm());
    m_timeCount++;
}

void Controller::handleInfReceive(int value)
{
   if(value == 1)
   {
       m_view->setFraredLab("Person:waring!");
       m_view->upDataLed(Widget::DEVICE_ALARM,Widget::COLOR_RED);
       m_beep->turnOn();
   }
   else
   {
       m_view->setFraredLab("Person:safe~");
       m_view->upDataLed(Widget::DEVICE_ALARM,Widget::COLOR_GREEN);
       m_beep->turnOff();
   }
}

void Controller::handleDataReceive(QString data)
{
    qDebug() << "receive:" << data;
}

void Controller::startToHost()
{
    bool ret;
    ret = m_client->connectToServer("192.168.137.150",8888);
    ret ? m_view->upDataLed(Widget::DEVICE_NETWORK,Widget::COLOR_GREEN) : m_view->upDataLed(Widget::DEVICE_NETWORK,Widget::COLOR_RED);
    m_client->sendData("hello server");
}

void Controller::setUpConnect()
{
   connect(m_view,&Widget::buttonClicked,this,&Controller::handleBtnClick);
   connect(m_timer,&QTimer::timeout,this,&Controller::handleTimer);
   connect(m_infThread,&MonitorThread::resultReady,this,&Controller::handleInfReceive);
   connect(m_client,&TcpClient::dataReceived,this,&Controller::handleDataReceive);
}
