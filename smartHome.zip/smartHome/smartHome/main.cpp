#include "widget.h"
#include "controller.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    Widget w;
    Controller ctl(&w);
    w.show();
    return a.exec();
}
