#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QString>
#include <QList>
#include <QMap>
#include <QtCharts>
#include <QtCharts>
#include <QChartView>
#include <QChart>
#include <QLineSeries>
#include <QBarSeries>
#include <QPieSeries>
#include <QBarSet>

QT_CHARTS_USE_NAMESPACE
QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    enum ButtonId{
        BTN_LED,
        BTN_BEEP,
        BTN_SLIDER,
        BTN_MOTOR_ENABLE,
        BTN_MOTOR_DIR,
        BTN_MOTOR_SPEED
    };
    enum LedDevice {
        DEVICE_LED,
        DEVICE_BEEP,
        DEVICE_NETWORK,
        DEVICE_MOTOR_STATUS,
        DEVICE_MOTOR_DIR,
        DEVICE_ALARM
    };
    enum LedColor {
        COLOR_GREY,
        COLOR_RED,
        COLOR_YELLOW,
        COLOR_GREEN
    };
    Q_ENUM(ButtonId);
    Q_ENUM(LedDevice);
    Q_ENUM(LedColor);

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();
    void setLedbtn(const QString& str) const;
    void setMotorBtn(ButtonId id,const QString& str) const;
    void setFraredLab(const QString& str) const;
    void setAngleLab(int value) const;
    void setLightPro(int value) const;
    void setMotorPro(int value) const;
    void setLightLab(double voltage) const;
    void upDateChart(int time, double cm) const;
    int getSliderValue() const;
    void upDataLed(LedDevice device, LedColor color, int size = 16) ;

private:
    Ui::Widget *ui;
    QChartView *m_chartView;
    QChart* m_chart;
    QValueAxis* m_axisX;
    QValueAxis* m_axisY;
    QLineSeries* m_lineSer;

private:
    void buildConnect();
    void setUpChart();
    void initLed();
    void setLED(QLabel* label, int color, int size);

signals:
    void buttonClicked(ButtonId id);
};
#endif // WIDGET_H
