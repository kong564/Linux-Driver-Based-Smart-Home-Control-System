#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);

    ui->sg90Slider->setRange(0,18);
    ui->sg90Slider->setValue(0);

    ui->Motor_Speed_Status->setRange(0,3);
    ui->progressBar->setTextVisible(true);
    ui->Motor_Speed_Status->setValue(0);

    ui->progressBar->setRange(0,4095);
    ui->progressBar->setTextVisible(true);

    initLed();
    setUpChart();
    buildConnect();
}

Widget::~Widget()
{
    delete ui;
}

void Widget::setLedbtn(const QString& str) const
{
    ui->ledBtn->setText(str);
}

void Widget::buildConnect()
{
    const QList<QPair<QPushButton*, ButtonId>> buttons = {
        {ui->ledBtn, BTN_LED},
        {ui->beepBtn, BTN_BEEP},
        {ui->Motor_speed_Btn,BTN_MOTOR_SPEED},
        {ui->Motor_enable_Btn,BTN_MOTOR_ENABLE},
        {ui->Motor_direction_Btn,BTN_MOTOR_DIR}
    };

    for (const auto &pair : buttons) {
        QPushButton* button = pair.first;
        ButtonId id = pair.second; // 直接获取值

        connect(button, &QPushButton::clicked, [this, id]() {
            emit buttonClicked(id);
        });
    }

    connect(ui->sg90Slider,&QSlider::valueChanged,[this](){
        emit buttonClicked(this->BTN_SLIDER);
    });

}

int Widget::getSliderValue() const
{
    return ui->sg90Slider->value();
}

void Widget::setAngleLab(int value) const
{
    QString str = "Angle:" + QString::number(value);
    ui->angleLab->setText(str);
}

void Widget::setLightPro(int value) const
{
    ui->progressBar->setValue(value);
}

void Widget::setMotorPro(int value) const
{
    ui->Motor_Speed_Status->setValue(value);
}

void Widget::setLightLab(double voltage) const
{
    QString str = "Volt:" + QString::number(voltage, 'f', 2) + "v";
    ui->lightLab->setText(str);
}

void Widget::setFraredLab(const QString &str) const
{
    ui->fraredLab->setText(str);
}

void Widget::upDateChart(int time, double cm) const
{
    m_lineSer->append(time, cm);

    if(m_lineSer->count() > 100)
    {
        m_lineSer->remove(0);
    }
    // 动态调整X轴范围
    if(m_axisX->max() < time)
    {
        m_axisX->setRange(time - 40,time + 1);
    }
}

void Widget::setUpChart()
{
    m_chartView = qobject_cast<QChartView*>(ui->graphicsView);
    if(m_chartView == nullptr)
    {
        qDebug() << "123";
    }
    m_chart = new QChart();
    m_axisX = new QValueAxis();
    m_axisY = new QValueAxis();
    m_lineSer = new QLineSeries();

    m_lineSer->setName("Distance_cm");
    m_chart->addSeries(m_lineSer);

    m_axisX->setRange(0,4);
    m_axisX->setGridLineVisible(true);
    m_axisX->setTickCount(5);
    m_axisX->setMinorTickCount(1);
    m_axisX->setTitleText("100ms");

    m_axisY->setRange(0,200);
    m_axisY->setGridLineVisible(true);
    m_axisY->setTickCount(5);
    m_axisY->setMinorTickCount(1);
    m_axisY->setTitleText("1cm");

    m_chart->addAxis(m_axisX,Qt::AlignBottom);
    m_chart->addAxis(m_axisY,Qt::AlignLeft);

    m_lineSer->attachAxis(m_axisX);
    m_lineSer->attachAxis(m_axisY);

    //m_chart->legend()->hide();

    m_chartView->setChart(m_chart);
    m_chartView->setRenderHint(QPainter::Antialiasing);
}

void Widget::setLED(QLabel *label, int color, int size)
{
    // 将label中的文字清空
       label->setText("");
       // 先设置矩形大小
       // 如果ui界面设置的label大小比最小宽度和高度小，矩形将被设置为最小宽度和最小高度；
       // 如果ui界面设置的label大小比最小宽度和高度大，矩形将被设置为最大宽度和最大高度；
       QString min_width = QString("min-width: %1px;").arg(size);              // 最小宽度：size
       QString min_height = QString("min-height: %1px;").arg(size);            // 最小高度：size
       QString max_width = QString("max-width: %1px;").arg(size);              // 最小宽度：size
       QString max_height = QString("max-height: %1px;").arg(size);            // 最小高度：size
       // 再设置边界形状及边框
       QString border_radius = QString("border-radius: %1px;").arg(size/2);    // 边框是圆角，半径为size/2
       QString border = QString("border:1px solid black;");                    // 边框为1px黑色
       // 最后设置背景颜色
       QString background = "background-color:";
       switch (color) {
       case LedColor::COLOR_GREY:
           // 灰色
           background += "rgb(190,190,190)";
           break;
       case LedColor::COLOR_RED:
           // 红色
           background += "rgb(255,0,0)";
           break;
       case LedColor::COLOR_GREEN:
           // 绿色
           background += "rgb(0,255,0)";
           break;
       case LedColor::COLOR_YELLOW:
           // 黄色
           background += "rgb(255,255,0)";
           break;
       default:
           break;
       }

       const QString SheetStyle = min_width + min_height + max_width + max_height + border_radius + border + background;
       label->setStyleSheet(SheetStyle);
}

void Widget::initLed()
{
    setLED(ui->Led_status,0,16);
    setLED(ui->Beep_status,0,16);
    setLED(ui->Motor_status,0,16);
    setLED(ui->Motor_direction_staus,0,16);
    setLED(ui->Network_status,0,16);
    setLED(ui->Alarm_status,0,16);
}

void Widget::upDataLed(LedDevice device, LedColor color, int size)
{
    switch (device) {
    case LedDevice::DEVICE_LED:
        setLED(ui->Led_status,color,size);
        break;
    case LedDevice::DEVICE_BEEP:
        setLED(ui->Beep_status,color,size);
        break;
    case LedDevice::DEVICE_ALARM:
        setLED(ui->Alarm_status,color,size);
        break;
    case LedDevice::DEVICE_MOTOR_STATUS:
        setLED(ui->Motor_status,color,size);
        break;
    case LedDevice::DEVICE_MOTOR_DIR:
        setLED(ui->Motor_direction_staus,color,size);
        break;
    case LedDevice::DEVICE_NETWORK:
        setLED(ui->Network_status,color,size);
        break;

    }
}

void Widget::setMotorBtn(ButtonId id, const QString &str) const
{
    switch (id)
    {
        case BTN_MOTOR_DIR:
            ui->Motor_direction_Btn->setText(str);
            break;

        case BTN_MOTOR_SPEED:
            ui->Motor_speed_Btn->setText(str);
            break;

        case BTN_MOTOR_ENABLE:
            ui->Motor_enable_Btn->setText(str);
            break;

        default:
            qDebug() << "only Motor！";
            break;
    }
}
