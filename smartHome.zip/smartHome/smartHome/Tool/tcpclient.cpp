#include "tcpclient.h"

TcpClient::TcpClient(QObject *parent) : QObject(parent)
{
    m_socket = new QTcpSocket(this);
    connect(m_socket,&QTcpSocket::readyRead,this,&TcpClient::onDataReceived);
}

bool TcpClient::connectToServer(const QString &host, quint16 port)
{
   m_socket->connectToHost(host,port);

   if(!m_socket->waitForConnected())
   {
       qDebug() << "connect to " << host << " failed";
       return false;
   }
   qDebug() << "connect to " << host << "success";
   return true;
}

bool TcpClient::isConnect() const
{
     return m_socket && m_socket->state() == QAbstractSocket::ConnectedState;
}

void TcpClient::sendData(const QString &data)
{
    if(!isConnect())
    {
        qDebug() << "connect is break can't send data";
        return;
    }
    if(m_socket->write(data.toUtf8()) == -1)
    {
        qDebug() << "fail to write data";
    }
    else
    {
        qDebug() << "success to write data";
    }
}

void TcpClient::disconnectToServer()
{
    if(isConnect())
    {
        m_socket->disconnectFromHost();
    }
}

void TcpClient::onDataReceived()
{
    auto data = m_socket->readAll();
    QString message = QString::fromUtf8(data).trimmed();
    qDebug() << "Receive data:" << message;
    emit dataReceived(message);
}
