#include "monitorthread.h"

MonitorThread::MonitorThread(QObject *parent):QThread(parent),m_stopFlag(false),m_infrared(new Infrared)
{

}

void MonitorThread::setFlag(int flag)
{
    m_stopFlag = flag;
}

void MonitorThread::run()
{
    struct input_event ev;
    while (!m_stopFlag)
    {
       ev = m_infrared->getStatus();
       if(ev.type == EV_KEY)
       {
           emit resultReady(ev.value);
       }
    }
}
