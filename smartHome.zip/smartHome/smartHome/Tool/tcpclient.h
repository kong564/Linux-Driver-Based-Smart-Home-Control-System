#ifndef TCPCLIENT_H
#define TCPCLIENT_H

#include <QTcpSocket>
#include <QObject>
#include <QDebug>
#include <QString>
#include <QByteArray>

class TcpClient : public QObject
{
    Q_OBJECT
public:
    explicit TcpClient(QObject *parent = nullptr);
    bool connectToServer(const QString &host, quint16 port);
    void sendData(const QString& data);
    void disconnectToServer();
    bool isConnect() const;

private:
    QTcpSocket *m_socket;

private slots:
    void onDataReceived();

signals:
    void dataReceived(QString data);

};

#endif // TCPCLIENT_H
