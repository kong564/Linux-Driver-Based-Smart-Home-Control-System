#ifndef MONITORTHREAD_H
#define MONITORTHREAD_H

#include <QObject>
#include <QThread>
#include "infrared.h"

class MonitorThread : public  QThread
{
    Q_OBJECT
public:
    explicit MonitorThread(QObject *parent = nullptr);
    void setFlag(int flag);

protected:
    virtual void run() Q_DECL_OVERRIDE;

private:
    int m_stopFlag = false;
    Infrared* m_infrared;

signals:
    void resultReady(int value);
};

#endif // MONITORTHREAD_H
