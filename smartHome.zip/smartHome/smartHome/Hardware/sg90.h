#ifndef SG90_H
#define SG90_H

class Sg90
{
private:
    int m_fd;        // 文件描述符
    int m_angel;     // 当前角度

public:
    Sg90();
    ~Sg90();
    void setAngle(int angle);
};

#endif // SG90_H
