#include "infrared.h"

Infrared::Infrared()
{
    m_fd = open("/dev/input/event2",O_RDONLY);
    if(m_fd < 0)
    {
        qDebug() << "event2 open failed";
    }

}

Infrared::~Infrared()
{
    if(m_fd > 0)
    {
        close(m_fd);
    }
}

struct input_event Infrared::getStatus()
{
    struct input_event ev;
    lseek(m_fd,0,SEEK_SET);
    int ret = read(m_fd, &ev, sizeof(ev));
    if(ret < 0)
    {
        qDebug() << "event3 read failed";
    }
    return ev;
}
