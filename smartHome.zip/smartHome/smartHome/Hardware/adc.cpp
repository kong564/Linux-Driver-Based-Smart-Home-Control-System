#include "adc.h"

Adc::Adc(QObject *parent) : QObject(parent)
{
    m_volt1_fd = open("/sys/bus/iio/devices/iio:device0/in_voltage1_raw",O_RDONLY);
    if(m_volt1_fd < 0)
    {
        qDebug() << "in_voltage1_raw open failed";
    }

    m_scale1_fd = open("/sys/bus/iio/devices/iio:device0/in_voltage_scale",O_RDONLY);
    if(m_scale1_fd < 0)
    {
        qDebug() << "in_voltage_scale open failed";
    }
}

int Adc::getValue1()
{
    char data[20] = {0};
    lseek(m_volt1_fd,0,SEEK_SET);
    int read_num = read(m_volt1_fd, data,sizeof(data) - 1);
    data[read_num] = '\0';
    m_value1 = atoi(data);
    return m_value1;
}

double Adc::getScale1()
{
    char data[20] = {0};
    lseek(m_scale1_fd,0,SEEK_SET);
    int read_num = read(m_scale1_fd, data,sizeof(data) - 1);
    data[read_num] = '\0';
    m_scale1 = atof(data);
    return m_scale1;
}

Adc::~Adc()
{
    if(m_volt1_fd > 0)
    {
         close(m_volt1_fd);
    }
    if(m_scale1_fd > 0)
    {
       close(m_scale1_fd);
    }
}
