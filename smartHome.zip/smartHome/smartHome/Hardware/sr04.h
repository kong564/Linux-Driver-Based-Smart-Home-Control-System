#ifndef SR04_H
#define SR04_H
#include <QObject>
#include <QDebug>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>

class Sr04
{
public:
    Sr04();
    ~Sr04();
    double getDistanceCm();
    bool isAvailable() const { return m_fd > 0; }

private:
    int m_fd;
    uint64_t m_ns;
};

#endif // SR04_H
