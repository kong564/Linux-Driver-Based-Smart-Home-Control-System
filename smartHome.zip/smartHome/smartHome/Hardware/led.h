#ifndef LED_H
#define LED_H
#include <QObject>
#include <QFile>
#include <QTextStream>

class Led : public QObject
{
    Q_OBJECT
public:
    Led();
    ~Led();
    void turnOn();
    void turnOff();
    void toggle();
    int getStatus() const;

private:
    int m_status;
    QFile* m_led;
};

#endif // LED_H
