#include "led.h"

Led::Led()
{
    m_status = 0;
    m_led = new QFile("/dev/gpioled");
}

Led::~Led()
{
    delete m_led;
    m_led = nullptr;
}
void Led::turnOn()
{
    if(m_led->open(QIODevice::WriteOnly | QIODevice::Text))
    {
        QTextStream out(m_led);
        out << "1";
        m_led->close();
    }
    m_status = 1;
}

void Led::turnOff()
{
    if(m_led->open(QIODevice::WriteOnly | QIODevice::Text))
    {
        QTextStream out(m_led);
        out << "0";
        m_led->close();
    }
    m_status = 0;
}

void Led::toggle()
{
    m_status ? turnOff() : turnOn();
}

int Led::getStatus() const
{
    return m_status;
}


