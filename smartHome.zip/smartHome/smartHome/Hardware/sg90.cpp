#include "sg90.h"
#include <QDebug>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>

Sg90::Sg90()
{
    m_fd = -1;
    m_angel = 0;

    m_fd = open("/dev/sg90", O_WRONLY);
}

Sg90::~Sg90()
{
    if (m_fd >= 0) {
        close(m_fd);
    }
}

void Sg90::setAngle(int angle)
{
    if (angle < 0) angle = 0;
    if (angle > 180) angle = 180;
    if (angle == m_angel) return;

    if (m_fd >= 0) {
        // 像C程序一样使用二进制写入
        unsigned char data = static_cast<unsigned char>(angle);

        ssize_t result = write(m_fd, &data, 1);

        if (result == 1) {
            m_angel = angle;

            // 添加微小延时
            usleep(10000); // 10ms
        }
    } else {
        qWarning() << "device not open";
    }
}
