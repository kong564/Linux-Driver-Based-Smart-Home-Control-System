#include "motor.h"
#include <QDebug>
Motor::Motor()
{
     m_enable = DISABLE;
     m_direction = LEFT;
     m_speed = SPEED_LOW;

    m_fd = open("/dev/motor", O_WRONLY);
    if(m_fd < 0)
    {
        qDebug() << "/dev/motor open failed";
    }
}

Motor::~Motor()
{
    setStatus(DISABLE);
    setSpeed(SPEED_LOW);
    setDirection(LEFT);
}

void Motor::setSpeed(MotorSpeed speed)
{
    m_speed = speed;
    switch (speed) {
        case SPEED_LOW:
            write(m_fd,"1",1);

            break;
        case SPEED_MIDDLE:
            write(m_fd,"2",1);

            break;
        case SPEED_HIGH:
            write(m_fd,"3",1);

            break;

    }
}

void Motor::setDirection(MotorDirection dir)
{
    if(m_enable == ENABLE)
    {
        dir == LEFT ? write(m_fd,"L",1) : write(m_fd,"R",1);
        m_direction = dir;
    }
    else
    {
        qDebug() << "Motor not enable";
    }
}

void Motor::setStatus(MotorStatus status)
{
    status == ENABLE ? write(m_fd,"E",1) : write(m_fd,"S",1);
    m_enable = status;
}

char Motor::getSpeed() const
{
    return m_speed;
}

char Motor::getStatus() const
{
    return m_enable;
}

char Motor::getDirection() const
{
    return m_direction;
}
