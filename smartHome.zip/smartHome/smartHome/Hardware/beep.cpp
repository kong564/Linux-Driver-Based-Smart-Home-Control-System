#include "beep.h"

Beep::Beep()
{
    m_status = 0;
    m_beep = new QFile("/dev/beep");
}

Beep::~Beep()
{
    delete m_beep;
    m_beep = nullptr;
}

void Beep::turnOn()
{
    if(m_beep->open(QIODevice::WriteOnly | QIODevice::Text))
    {
        QTextStream out(m_beep);
        out << "1";
        m_beep->close();
    }
    m_status = 1;
}

void Beep::turnOff()
{
    if(m_beep->open(QIODevice::WriteOnly | QIODevice::Text))
    {
        QTextStream out(m_beep);
        out << "0";
        m_beep->close();
    }
    m_status = 0;
}

void Beep::toggle()
{
    m_status ? turnOff() : turnOn();
}

int Beep::getStatus() const
{
    return m_status;
}
