#include "sr04.h"

Sr04::Sr04() : m_fd(-1), m_ns(0)
{
    m_fd = open("/dev/sr04",O_RDONLY);
    if(m_fd < 0)
    {
        qDebug() << "/dev/sr04 open failed";
    }
}

Sr04::~Sr04()
{
    if(isAvailable())
    {
        close(m_fd);
    }
}

double Sr04::getDistanceCm()
{
    int ret;

    if(!isAvailable())
    {
        qDebug() << "Invalid fd!";
        return -1;
    }

    lseek(m_fd,0,SEEK_SET);
    ret = read(m_fd,&m_ns,4);

    if(ret != 4)
    {
        qDebug() << "/dev/sr04 read failed";
        return -1;
    }
    return m_ns * 0.000017f;
}
