#ifndef BEEP_H
#define BEEP_H
#include <QObject>
#include <QFile>
#include <QTextStream>

class Beep : public QObject
{
    Q_OBJECT
public:
    Beep();
    ~Beep();
    void turnOn();
    void turnOff();
    void toggle();
    int getStatus() const;

private:
    int m_status;
    QFile* m_beep;  
};


#endif // BEEP_H
