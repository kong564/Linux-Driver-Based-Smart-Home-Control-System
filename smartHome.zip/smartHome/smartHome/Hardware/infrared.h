#ifndef INFRARED_H
#define INFRARED_H

#include <QObject>
#include <QDebug>
#include <linux/input.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>

class Infrared
{
private:
    int m_fd;
public:
    Infrared();
    ~Infrared();
    struct input_event getStatus();
};

#endif // INFRARED_H
