#ifndef ADC_H
#define ADC_H

#include <QObject>
#include <QDebug>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>

class Adc : public QObject
{
    Q_OBJECT
public:
    explicit Adc(QObject *parent = nullptr);
    ~Adc();
    double getScale1();
    int getValue1();

private:
    double m_scale1;
    int m_value1;
    int m_volt1_fd;
    int m_scale1_fd;

signals:

};

#endif // ADC_H
