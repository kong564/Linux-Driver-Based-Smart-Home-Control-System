#ifndef MOTOR_H
#define MOTOR_H
#include <QObject>
#include <QDebug>
#include <unistd.h>
#include <fcntl.h>
#include <sys/ioctl.h>

class Motor
{
public:
    enum MotorStatus
    {
        ENABLE = 'E',
        DISABLE = 'S'

    };
    enum MotorDirection
    {
        LEFT = 'L',
        RIGHT = 'R'
    };
    enum MotorSpeed
    {
        SPEED_LOW = '1',
        SPEED_MIDDLE = '2',
        SPEED_HIGH = '3'
    };


public:
    Motor();
    ~Motor();
    void setDirection(MotorDirection dir);
    void setSpeed(MotorSpeed speed);
    void setStatus(MotorStatus status);
    char getStatus() const;
    char getDirection() const;
    char getSpeed() const;

private:
    int m_fd;
    MotorStatus m_enable;
    MotorDirection m_direction;
    MotorSpeed m_speed;
};

#endif // MOTOR_H
