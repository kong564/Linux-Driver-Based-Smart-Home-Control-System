QT       += core gui
QT       += network
QT       += charts
greaterThan(QT_MAJOR_VERSION, 4): QT += widgets

CONFIG += c++11

# The following define makes your compiler emit warnings if you use
# any Qt feature that has been marked deprecated (the exact warnings
# depend on your compiler). Please consult the documentation of the
# deprecated API in order to know how to port your code away from it.
DEFINES += QT_DEPRECATED_WARNINGS

# You can also make your code fail to compile if it uses deprecated APIs.
# In order to do so, uncomment the following line.
# You can also select to disable deprecated APIs only up to a certain version of Qt.
#DEFINES += QT_DISABLE_DEPRECATED_BEFORE=0x060000    # disables all the APIs deprecated before Qt 6.0.0

SOURCES += \
    Controller/controller.cpp \
    Hardware/motor.cpp \
    Tool/monitorthread.cpp \
    Tool/tcpclient.cpp \
    Hardware/adc.cpp \
    Hardware/beep.cpp \
    Hardware/infrared.cpp \
    Hardware/led.cpp \
    Hardware/sg90.cpp \
    Hardware/sr04.cpp \
    View/widget.cpp \
    main.cpp

HEADERS += \
    Controller/controller.h \
    Hardware/motor.h \
    Tool/monitorthread.h \
    Tool/tcpclient.h \
    Hardware/adc.h \
    Hardware/beep.h \
    Hardware/infrared.h \
    Hardware/led.h \
    Hardware/sg90.h \
    Hardware/sr04.h \
    View/widget.h

INCLUDEPATH += \
    Controller \
    Hardware \
    Tool \
    View

FORMS += \
    widget.ui

# Default rules for deployment.
qnx: target.path = /tmp/$${TARGET}/bin
else: unix:!android: target.path = /opt/$${TARGET}/bin
!isEmpty(target.path): INSTALLS += target
