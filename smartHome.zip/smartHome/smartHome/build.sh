make clean
if make -j4; then
	cp smartHome /mnt/hgfs/Public/
	echo "smartHome has been copied to Public"
else
	echo "make failed"
	exit 1
fi	
